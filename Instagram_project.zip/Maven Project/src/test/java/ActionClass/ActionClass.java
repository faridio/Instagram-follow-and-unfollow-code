package ActionClass;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import java.util.List;

public class ActionClass {
  //  private static ChromeDriverUtil chrome;
 //   static WebDriver driver = chrome.getDriver();
    @Test
    public void rightClick1() {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.navigate().to("https://the-internet.herokuapp.com/context_menu");
        WebElement hotSpot = driver.findElement(By.id("hot-spot"));
        Actions actions = new Actions(driver);
        actions.contextClick(hotSpot).perform();
    }
    @Test
    public void rightClick2() {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.navigate().to("https://the-internet.herokuapp.com/context_menu");
        WebElement hotSpot = driver.findElement(By.id("hot-spot"));
        Actions actions = new Actions(driver);
        Action action = actions.contextClick(hotSpot).build();
        action.perform();
    }
    @Test
    public void hoverOver() throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.navigate().to("https://the-internet.herokuapp.com/hovers");
        List<WebElement> avatarText = driver.findElements(By.xpath("//h5"));
        List<WebElement> avatars = driver.findElements(By.xpath("//img[@alt='User Avatar']"));
        Actions actions = new Actions(driver);
        for(int i=0; i<avatars.size();i++) {
            actions.moveToElement(avatars.get(i)).perform();
            System.out.println(avatarText.get(i).getText());
        }
    }


    }
