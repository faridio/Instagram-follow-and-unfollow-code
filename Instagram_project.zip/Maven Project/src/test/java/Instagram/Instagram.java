package Instagram;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class Instagram {

    public static void main(String[] args) throws Exception {

        WebDriver driver = UtilityGoogle.getDriver();
        driver.get("https://www.instagram.com");
        InstagramUtils instagram = new InstagramUtils(driver);

        Thread.sleep(3000);
        instagram.login();

        Thread.sleep(3000);
        instagram.closePopup();

        Thread.sleep(3000);
        instagram.seeAll();

        Thread.sleep(3000);

        for (int i = 0; i < 3; i++) {
            instagram.followThirtyPeople();
            instagram.refresh();
            Thread.sleep(3000);
        }

        instagram.profilePage();
        Thread.sleep(3000);
        instagram.currentFollowers();
        Thread.sleep(3000);

        instagram.unfollowFollowers();
        Thread.sleep(3000);



        driver.close();

    }
}
