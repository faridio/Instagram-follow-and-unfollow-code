package Instagram;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class InstagramUtils {
    private WebDriver driver;

    public InstagramUtils(WebDriver driver) {
        this.driver = driver;
    }

    public void login() {
        driver.findElement(By.name("username")).clear();
        driver.findElement(By.name("username")).sendKeys("wbtester001");
        driver.findElement(By.name("password")).clear();
        driver.findElement(By.name("password")).sendKeys("Test@12345");
        driver.findElement(By.xpath("//*[@id=\"react-root\"]/section/main/article/div[2]/div[1]/div/form/div[4]/button")).submit();
    }

    public void closePopup() {
        driver.findElement(By.xpath("//div/button[@class='aOOlW   HoLwm ']")).click();
    }

    public void seeAll() {
        driver.findElement(By.xpath("//a/div[@class='_7UhW9  PIoXz        qyrsm KV-D4        uL8Hv         ']")).click();
    }

    public void followThirtyPeople() throws InterruptedException {
        for (int i = 1; i <= 30; i++) {
            WebElement button = driver.findElement(By.xpath("//*[@id=\"react-root\"]/section/main/div/div[2]/div/div/div[" + i + "]/div[3]/button"));
            button.click();
            Thread.sleep(333);
        }
    }

    public void profilePage() {
        driver.findElement(By.xpath("//*[@id=\"react-root\"]/section/nav/div[2]/div/div/div[3]/div/div[5]/a")).click();
    }

    public void currentFollowers() {
        driver.findElement(By.xpath("//*[@id=\"react-root\"]/section/main/div/header/section/ul/li[2]/a")).click();
    }

    public void unfollowFollowers() throws InterruptedException {
        WebElement container = driver.findElement(By.xpath("/html/body/div[4]/div/div[2]/ul/div"));
        List<WebElement> children = container.findElements(By.xpath("*"));
        for (int i = 1; i <= children.size(); i++) {
            WebElement button = driver.findElement(By.xpath("/html/body/div[4]/div/div[2]/ul/div/li[" + i + "]/div/div[3]/button"));
            if (button.getText().equals("Following")) {
                button.click();
                Thread.sleep(3000);
                WebElement newButton = driver.findElement(By.xpath("/html/body/div[5]/div/div/div[3]/button[1]"));
                newButton.click();
                Thread.sleep(3000);
            }
        }
        driver.findElement(By.xpath("/html/body/div[4]/div/div[1]/div/div[2]/button")).click();
    }

    public void refresh() {
        driver.navigate().refresh();
    }
}
