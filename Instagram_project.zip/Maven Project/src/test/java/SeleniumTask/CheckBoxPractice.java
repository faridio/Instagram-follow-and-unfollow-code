package SeleniumTask;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CheckBoxPractice {

    @Test
    public void Test1() throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.get("http://amazon.com");
        WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
        searchBox.sendKeys("Iphone");
        //submit() method
        //driver.findElement(By.className("nav-input")).submit();
        driver.findElement(By.xpath("//div/input[@type='submit']")).submit();
        Thread.sleep(2000);
        WebElement apple = driver.findElement(By.xpath("//li[@id='p_89/Apple']//i"));
        apple.click();
        Thread.sleep(2000);
        apple = driver.findElement(By.xpath("//li[@id='p_89/Apple']//input"));
        Assert.assertTrue(apple.isSelected());








    }


}
