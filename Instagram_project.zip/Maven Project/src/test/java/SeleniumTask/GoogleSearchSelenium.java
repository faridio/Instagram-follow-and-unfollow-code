package SeleniumTask;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

public class GoogleSearchSelenium {
    public static void main(String[] args) throws InterruptedException {

        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.get("http://www.google.com");

        WebElement search = driver.findElement(By.name("q"));
        search.sendKeys("Selenium");

        driver.findElement(By.name("btnK")).click();

        WebElement searchingResult = driver.findElement(By.name("q"));

        List<WebElement> listResult = searchingResult.findElements(By.xpath("//h3[@class='LC20lb DKV0Md']"));
        System.out.println(listResult.size());

        for (WebElement results : listResult) {
            String value = results.getText();
//            System.out.println(value);

            if(!value.equals("")){
                if(value.contains("Selenium") || value.contains("selenium")){
                    System.out.println("Include Selenium");
                }else {
                    System.out.println("Not Include Selenium");
                }
            }

        }


        driver.quit();
        driver.close();

    }
}