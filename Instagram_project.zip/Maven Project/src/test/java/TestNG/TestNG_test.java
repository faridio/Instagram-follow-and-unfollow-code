package TestNG;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestNG_test {

        @Test
        public void test1(){                  //test1 test2 will print by ascending example: 1,2,3,4,5
        System.out.println("Testing 1st test");
            Assert.assertEquals("Mothers Day", "Mothers Day");
            System.out.println("After Assert");


        }


        @Test
        public void test2(){
            System.out.println("Testing 2nd test");
            Assert.assertTrue("Mothers Day".startsWith("Mother"));
            System.out.println("After 2nd assertion");

        }



}
