package ProjectDay;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class Projectday1 {

    @Test
    public void test1() throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.navigate().to("http://secure.smartbearsoftware.com/samples/TestComplete11/WebOrders/Login.aspx?");
        String title = driver.getTitle();
        Assert.assertEquals(title, "Web Orders Login");
        driver.findElement(By.name("ctl00$MainContent$username")).sendKeys("Tester");
        driver.findElement(By.name("ctl00$MainContent$password")).sendKeys("test");
        driver.findElement(By.name("ctl00$MainContent$login_button")).click();
        title = driver.getTitle();
        Assert.assertEquals(title, "Web Orders");
        String selected = driver.findElement(By.xpath("//ul/*")).getText();
        Assert.assertEquals(selected, "View all orders");
        String header = driver.findElement(By.xpath("//h2")).getText();
        Assert.assertEquals(header, "List of All Orders");
        driver.close();
    }

    @Test
    public void test2(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver=new ChromeDriver();
        driver.get("http://secure.smartbearsoftware.com/samples/TestComplete11/WebOrders/Login.aspx?");
        driver.findElement(By.name("ctl00$MainContent$username")).sendKeys("Tester");
        driver.findElement(By.name("ctl00$MainContent$password")).sendKeys("test");
        driver.findElement(By.name("ctl00$MainContent$login_button")).click();
        WebElement viewAllProducts=driver.findElement(By.xpath("//a[@href='Products.aspx']"));
        viewAllProducts.click();
        Assert.assertTrue(driver.getCurrentUrl().contains("Product"));
        driver.close();
    }
    @Test
    public void test3(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver=new ChromeDriver();
        driver.get("http://secure.smartbearsoftware.com/samples/TestComplete11/WebOrders/Login.aspx?");
        driver.findElement(By.name("ctl00$MainContent$username")).sendKeys("Tester");
        driver.findElement(By.name("ctl00$MainContent$password")).sendKeys("test");
        driver.findElement(By.name("ctl00$MainContent$login_button")).click();
        List<WebElement> lists=driver.findElements(By.xpath("//li/a"));
        List<String> expectedLinks= new ArrayList();
        expectedLinks.add("Default.aspx");
        expectedLinks.add("Products.aspx");
        expectedLinks.add("Process.aspx");
        int count=0;
        for (WebElement list:lists){
            System.out.println(list.getAttribute("href"));
            Assert.assertTrue(list.getAttribute("href").contains(expectedLinks.get(count++)));
        }
        //Validate their href values are equals to :
        WebElement validatelink1 = driver.findElement(By.xpath("//ul/li[1]/a"));
        String link1 = validatelink1.getAttribute("href");
        boolean result1 = link1.contains(expectedLinks.get(0));
        System.out.println(result1);

        WebElement validatelink2 = driver.findElement(By.xpath("//ul/li[2]/a"));
        String link2 = validatelink2.getAttribute("href");
        boolean result2 = link2.contains(expectedLinks.get(1));
        System.out.println(result2);

        WebElement validatelink3 = driver.findElement(By.xpath("//ul/li[3]/a"));
        String link3 = validatelink3.getAttribute("href");
        boolean result3 = link3.contains(expectedLinks.get(2));
        System.out.println(result3);
        driver.close();
    }

    @Test
    public void test4() throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.get("http://secure.smartbearsoftware.com/samples/TestComplete11/WebOrders/Login.aspx?");
        Thread.sleep(3000);
        driver.findElement(By.name("ctl00$MainContent$username")).sendKeys("Tester");
        driver.findElement(By.name("ctl00$MainContent$password")).sendKeys("test");
        driver.findElement(By.name("ctl00$MainContent$login_button")).click();
        driver.findElement(By.xpath("//ul/li[3]/a")).click();
        Select screenSaverMenu = new Select(driver.findElement(By.name("ctl00$MainContent$fmwOrder$ddlProduct")));
        screenSaverMenu.selectByVisibleText("ScreenSaver");
        WebElement quantity = driver.findElement(By.name("ctl00$MainContent$fmwOrder$txtQuantity"));
        quantity.clear();
        quantity.sendKeys("5");
        WebElement customerName = driver.findElement(By.name("ctl00$MainContent$fmwOrder$txtName"));
        customerName.sendKeys("Techtorial Academy");
        WebElement streetName = driver.findElement(By.name("ctl00$MainContent$fmwOrder$TextBox2"));
        streetName.sendKeys("2200 E devon");
        WebElement cityName = driver.findElement(By.name("ctl00$MainContent$fmwOrder$TextBox3"));
        cityName.sendKeys("Des Plaines");
        WebElement state = driver.findElement(By.name("ctl00$MainContent$fmwOrder$TextBox4"));
        state.sendKeys("Illinois");
        WebElement zipCode = driver.findElement(By.name("ctl00$MainContent$fmwOrder$TextBox5"));
        zipCode.sendKeys("60018");
        driver.findElement(By.id("ctl00_MainContent_fmwOrder_cardList_1")).click();
        WebElement cardNumber=driver.findElement(By.id("ctl00_MainContent_fmwOrder_TextBox6"));
        cardNumber.sendKeys("444993876233");
        WebElement expDate=driver.findElement(By.id("ctl00_MainContent_fmwOrder_TextBox1"));
        expDate.sendKeys("03/21");
        Thread.sleep(3000);
        driver.findElement(By.id("ctl00_MainContent_fmwOrder_InsertButton")).click();
        System.out.println("Case 4 part2");
        WebElement result = driver.findElement(By.xpath("//strong"));
        Assert.assertTrue(result.isDisplayed());
        driver.findElement(By.xpath("//ul/li[1]/a")).click();

        List<WebElement> expectedOrder=driver.findElements(By.xpath("//div/table/tbody/tr[2]/td"));
        List<String> expectedList = new ArrayList<>();
        expectedList.add("");
        expectedList.add("Techtorial Academy");
        expectedList.add("ScreenSaver");
        expectedList.add("5");
        expectedList.add("05/12/2020");
        expectedList.add("2200 E Devon");
        expectedList.add("Des Plaines");
        expectedList.add("Illinois");
        expectedList.add("60659");
        expectedList.add("MasterCard");
        expectedList.add("444993876233");
        expectedList.add("03/21");
        expectedList.add("");
        for(int i=0; i<expectedOrder.size();i++){
            Assert.assertEquals(expectedOrder.get(i).getText(),expectedList.get(i));
        }
        Thread.sleep(3000);
        driver.close();

    }
    }