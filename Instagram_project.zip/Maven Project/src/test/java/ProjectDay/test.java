//        System.out.println("Case 4");
//
//        /*
//        Navigate to
//        "http://secure.smartbearsoftware.com/sampl
//        es/TestComplete11/WebOrders/Login.aspx?"
//        Input username "Tester"
//        Input password "Test"
//        Click login button
//        Click "Order" button
//        Select product "Screen Saver"
//        Input quantity 5
//        Input Customer name "Techtorial Academy"
//        Input Street "2200 E devon"
//        Input City "Des Plaines"
//        Input State "Illinois"
//        Input Zip "60018"
//        Select MasterCard
//        Input card number "444993876233"
//        Input expiration date "03/21"
//        Click Process button
//         */
//
//        driver.navigate().to("http://secure.smartbearsoftware.com/samples/TestComplete11/WebOrders/Login.aspx?");
//
//        Thread.sleep(1000);
//
//        WebElement userName3 = driver.findElement(By.id("ctl00_MainContent_username"));
//        userName3.sendKeys("tester");
//
//        WebElement password3 = driver.findElement(By.id("ctl00_MainContent_password"));
//        password3.sendKeys("test");
//
//        WebElement submit3 = driver.findElement(By.id("ctl00_MainContent_login_button"));
//        submit3.click();
//
//        Thread.sleep(2000);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
